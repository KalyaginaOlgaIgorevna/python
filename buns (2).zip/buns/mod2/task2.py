import math
dlina = int(input())
#периметр
P = dlina * 4
#площадь
S = dlina * dlina
#диагональ
D = dlina * math.sqrt(2)

print(P,S,round(D, 2))
