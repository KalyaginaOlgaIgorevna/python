def st(n):
    a = ch
    if n % 2 == 0:
        return (a**2)**(n/2)
    else:
        return a*(a**(n-1))

ch = int(input())
s = int(input())
print(st(s))