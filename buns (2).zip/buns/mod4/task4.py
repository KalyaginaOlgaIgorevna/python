s = input()
c =list(s)
m=[]
if s == s[::-1]:
    print("Да")
else:
    for i in s:
        if c.count(i)>1:
            n = s.find(i)
            lent = len(s)
            if n%3==0:
                k = s.find(i,n)
                if (k - n)%4 ==0:
                    m.append(i)
                else:
                    continue
            else:
                continue
        else:
            continue
    if len(m) > 1:
        print("ДА")
    else:
        print("НЕТ")