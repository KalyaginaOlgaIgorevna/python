class stack:
    def __init__(self) -> None:
        self.list=list()
    def push(self, element) -> None:
        self.list.append(element)
    def get(self):
        if len(self.list) == 0:
            pass
        else:
            return self.list.pop()
    def isempty(self) -> bool:
        return len(self.list) == 0
st = stack()
for i in range(1, 101):
    st.push(i)
print(st.isempty())
for i in range(1, 101):
    print(st.get())
print(st.isempty())
print(st.get())