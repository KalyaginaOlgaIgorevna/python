sp = input().split(",")
b = []

if sp.count(sp[0]) == len(sp):
    print("Все числа равны")
elif len(set(sp)) == len(sp):
    print("Все числа разные")
else:
    for i in sp:
        if sp.count(i) > 1 and i not in b:
            b.append(i)
            print("Есть равные и неравные числа")