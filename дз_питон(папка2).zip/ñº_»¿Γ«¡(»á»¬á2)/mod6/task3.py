def get_armstrong_numbers():
    num = 10  # Начинаем с числа 10, так как числа 0-9 не учитываются
    while True:
        digits = [int(x) for x in str(num)]  # Получаем список цифр числа
        power = len(digits)  # Количество цифр в числе
        sum_of_powers = sum([x ** power for x in digits])  # Сумма степеней цифр числа
        if num == sum_of_powers:  # Если число является числом Армстронга
            yield num  # Возвращаем число с помощью генератора
        num += 1  # Переходим к следующему числу

# Пример использования
generator = get_armstrong_numbers()
for i in range(8):
    print(next(generator), end=' ')