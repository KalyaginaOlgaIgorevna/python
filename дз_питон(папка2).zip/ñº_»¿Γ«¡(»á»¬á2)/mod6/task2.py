class DoubleElement:
    def __init__(self, *lst):
        self.lst = lst  # Сохраняем переданный список
        self.index = 0  # Инициализируем индекс для отслеживания текущего элемента

    def __next__(self):
        if self.index >= len(self.lst):  # Если индекс выходит за пределы списка, вызываем исключение StopIteration
            raise StopIteration
        if self.index + 1 < len(self.lst):  # Если доступны два следующих элемента
            pair = (self.lst[self.index], self.lst[self.index + 1])  # Формируем пару элементов
        else:
            pair = (self.lst[self.index], None)  # Если доступен только один следующий элемент, вторым элементом пары будет None
        self.index += 2  # Увеличиваем индекс на 2 для перехода к следующей паре элементов
        return pair

    def __iter__(self):
        return self  # Возвращаем сам объект в качестве итератора

dL = DoubleElement(1, 2, 3, 4)
for pair in dL:
    print(pair)
print()
dL = DoubleElement(1, 2, 3, 4, 5)
for pair in dL:
    print(pair)