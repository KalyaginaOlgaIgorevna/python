import requests
from bs4 import BeautifulSoup

# Определяем URL для парсинга
url = 'http://www.columbia.edu/~fdc/sample.html'

# Отправляем GET-запрос на указанный URL и сохраняем ответ
response = requests.get(url)

# Создаем объект BeautifulSoup для парсинга HTML
soup = BeautifulSoup(response.text, 'html.parser')

# Находим все элементы h3 в разобранном HTML и извлекаем текст
items = [h3.text for h3 in soup.findAll('h3')]

# Выводим извлеченный текст
print(items)