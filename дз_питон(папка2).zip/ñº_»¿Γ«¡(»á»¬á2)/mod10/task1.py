import requests
import json

def get_millennium_falcon_info():
    # Запрос информации о корабле Millennium Falcon
    url = "https://swapi.dev/api/starships/10/"
    response = requests.get(url)
    data = response.json()

    # Извлечение необходимых данных
    name = data['name']
    max_speed = data['max_atmosphering_speed']
    starship_class = data['starship_class']
    pilots = []

    # Получение информации о каждом пилоте
    for pilot_url in data['pilots']:
        pilot_response = requests.get(pilot_url)
        pilot_data = pilot_response.json()

        # Извлечение данных о пилоте
        pilot_name = pilot_data['name']
        pilot_height = pilot_data['height']
        pilot_mass = pilot_data['mass']
        pilot_homeworld = pilot_data['homeworld']

        # Получение информации о родной планете пилота
        homeworld_response = requests.get(pilot_homeworld)
        homeworld_data = homeworld_response.json()
        homeworld_name = homeworld_data['name']
        homeworld_url = homeworld_data['url']

        # Создание словаря с информацией о пилоте
        pilot_info = {
            'name': pilot_name,
            'height': pilot_height,
            'mass': pilot_mass,
            'homeworld': homeworld_name,
            'homeworld_url': homeworld_url
        }

        # Добавление информации о пилоте в список
        pilots.append(pilot_info)

    # Создание словаря с информацией о корабле Millennium Falcon
    info = {
        'ship_name': name,
        'starship_class': starship_class,
        'max_atmosphering_speed': max_speed,
        'pilots': pilots
    }

    return info

millennium_falcon_info = get_millennium_falcon_info()

# Вывод информации в консоль
print(json.dumps(millennium_falcon_info, indent=4))

# Сохранение информации в JSON-файл
with open('millennium_falcon_info.json', 'w') as file:
    json.dump(millennium_falcon_info, file, indent=4)