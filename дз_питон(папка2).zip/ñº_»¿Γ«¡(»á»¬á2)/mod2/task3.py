a, b, c = map(int, input().split(","))

if a > b:
    a, b = b, a
    if b > c:
        b, c = c, b
if a > c:
    a, c = c, a
    if c > b:
        c, b = b, c
if b > c:
    b, c = c, b
    if a > b:
        a, b = b, a

print(b)