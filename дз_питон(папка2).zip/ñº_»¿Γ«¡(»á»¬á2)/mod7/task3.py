def timer(func):
    def wrapper(*args, **kwargs):
        import datetime
        start_time = datetime.datetime.now()  # Запоминаем текущее время перед выполнением функции
        result = func(*args, **kwargs)  # Выполняем функцию
        end_time = datetime.datetime.now()  # Запоминаем текущее время после выполнения функции
        execution_time = end_time - start_time  # Вычисляем время выполнения
        print(f"Время выполнения функции {func.__name__}: {execution_time.total_seconds()} секунд")
        return result
    return wrapper

def memoize(func):
    cache = {}
    def wrapper(*args):
        if args in cache:
            return cache[args]
        result = func(*args)
        cache[args] = result
        return result
    return wrapper

@timer
@memoize
def fibonacci(n):
    if n < 2:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)

# Вызов функции fibonacci с декораторами timer и memoize
fibonacci(35)