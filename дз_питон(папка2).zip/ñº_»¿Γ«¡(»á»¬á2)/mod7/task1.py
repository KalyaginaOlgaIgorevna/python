def validate_args(func):
    # Объявляем декоратор validate_args, который будет проверять аргументы функции

    def wrapper(*args):
        # Внутренняя функция-обертка, которая будет вызываться вместо исходной функции

        if len(args) < 1:
            # Проверяем, что передан ровно один аргумент
            return "Not enough arguments"  # Возвращаем ошибку, если передано меньше одного аргумента

        elif len(args) > 1:
            # Проверяем, что передан только один аргумент
            return "Too many arguments"  # Возвращаем ошибку, если передано больше одного аргумента

        elif not isinstance(args[0], int):
            # Проверяем, что аргумент является целым числом
            return "Wrong types"  # Возвращаем ошибку, если аргумент не является целым числом

        elif args[0] < 0:
            # Проверяем, что аргумент не является отрицательным числом
            return "Negative argument"  # Возвращаем ошибку, если аргумент является отрицательным числом

        else:
            # Если все проверки пройдены успешно, вызываем исходную функцию с переданными аргументами
            return func(*args)

    return wrapper

@validate_args
def calculate_square(num):
    return num ** 2

# Проверка случая "Not enough arguments"
result1 = calculate_square()
print(result1)  # Вывод: "Not enough arguments"

# Проверка случая "Too many arguments"
result2 = calculate_square(5, 6)
print(result2)  # Вывод: "Too many arguments"

# Проверка случая "Wrong types"
result3 = calculate_square("abc")
print(result3)  # Вывод: "Wrong types"

# Проверка случая "Negative argument"
result4 = calculate_square(-5)
print(result4)  # Вывод: "Negative argument"

# Проверка случая, когда аргумент проходит валидацию
result5 = calculate_square(3)
print(result5)  # Вывод: 9